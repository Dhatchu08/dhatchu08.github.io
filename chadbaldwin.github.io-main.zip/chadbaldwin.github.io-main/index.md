# Hi! 🙋‍♂️

Just your average everyday nerd, developer, motorcycle enthusiast, dog dad.

The business side of this blog is mostly about SQL Server, PowerShell, programming tips and tools.

I also like to post about my hobbies...motorcycles, rubiks cubes, dogs, nerdy home projects, archery and whatever else I seem to be obsessing over that month.

Hope you enjoy what you're reading here!