---
layout: post
title: Starting a new personal blog!
description: I've decided to expand my blog to talk about personal items and fun projects I work on at home.
date: 2021-05-30 15:50:00 -0000
tag: Blog
---

Not sure how this is going to go...or if I'm getting in over my head. I thought it would be fun to talk about some of the personal projects I work on at home. I enjoy writing and sharing; Reddit is good for this kind of stuff, but it's not really the best environment for "Here's what I've been up to" posts.

You don't necessarily need to be a nerd to follow my personal posts...but it would probably help as a lot of my posts will be technical and nerdy.

Just to name a few of my interests...

* 3D Printing
* Rubiks Cubes / Puzzle Cubes
* Motorcycles
* Archery
* Dogs
* Technical home projects...such as Raspberry Pi's, electronics, smart home
* Non-technical home projects like organization

If any of this sounds interesting to you, then I hope you stick around and check in from time to times. I'll share new posts on Twitter and possibly LinkedIn.